import React from 'react'

export default function singlePage() {
  return (
    <div>
      
    </div>
  )
}
